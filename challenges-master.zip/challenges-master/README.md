## Desafios Front-end
Esta pasta se destina para futuros canditados a vagas de desenvolverdor(a) front-end na [Enext](www.enext.com.br).

Hoje temos dois testes técnico disponíveis para diferentes niveis de conhecimento:
* [`challenge-one`](https://github.com/enext-wpp/challenges/tree/master/challenge-one) requer um nível de conhecimento básico.
* [`challenge-two`](https://github.com/enext-wpp/challenges/tree/master/challenge-two) requer um nível de conhecimento intermediario.